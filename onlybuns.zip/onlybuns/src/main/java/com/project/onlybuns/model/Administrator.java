/*package com.project.onlybuns.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

    @Entity
    //@Table(name = "administrators")
    public class Administrator extends User {

        // Konstruktor bez parametara
        public Administrator() {
            super();
            this.setUserType(UserType.ADMINISTRATOR); // Postavlja tip korisnika na ADMINISTRATOR
        }

        // Konstruktor sa parametrima
        public Administrator(String username, String password, String email, String firstName, String lastName, String address) {
            super(username, password, email, firstName, lastName, address, UserType.ADMINISTRATOR);
        }

        // Ovde možeš dodati specifične metode i atribute za administratora, ako su potrebni
    }*/


