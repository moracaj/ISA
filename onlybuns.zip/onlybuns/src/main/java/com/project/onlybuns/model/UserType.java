package com.project.onlybuns.model;

//public enum UserType {
//    REGISTERED_USER,
//    ADMINISTRATOR
//}

public enum UserType {
    ROLE_ADMIN,
    ROLE_REGISTERED
}