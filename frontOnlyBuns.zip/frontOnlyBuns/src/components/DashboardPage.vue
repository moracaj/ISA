<template>
  <div class="dashboard">
    <h1>Dashboard</h1>
    <p>This is your dashboard where you can see various stats and information.</p>
  </div>
</template>

<script>
export default {
  name: 'DashboardPage',
  // You can add data, computed properties, methods, etc. here
};
</script>

<style scoped>
.dashboard {
  padding: 20px;
  font-family: Arial, sans-serif;
}
</style>
