<template>
    <div class="signin-page">
      <!-- Ova stranica je prazna -->
    </div>
  </template>
  
  <script>
  export default {
    name: 'SignIn'
  }
  </script>
  
  <style>
  .signin-page {
    background-color: #a72828; /* Zeleno pozadinsko */
    min-height: 100vh; /* Pokriva celu visinu stranice */
}

  
  </style>
  